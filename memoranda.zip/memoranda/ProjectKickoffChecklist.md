For each of you individually copy the checklist and check them of if it is done. This will be graded.

<MyName>
  
- [ ] Download and install Git
  
- [ ] I have a GitHub account with a username that we can map to your real name

- [ ] Filled out the individual survey for group forming

- [ ] Received a Taiga invite

- [ ] Accepted the Taiga invite

- [ ] Do you check Slack regularly

- [ ] Did you contact your team members

- [ ] Did you read the kickoff document

- [ ] Did you understand the kickoff document

- [ ] Did you make your three changes to the Memoranda software

- [ ] Did you read the DeliverableX.md document and understand it (if you do not understand ask your team or me)

- [ ] Did you read the QualityPolicy.md doument and understand it (if you do not understand ask your team or me)

- [ ] You understand how to get started and what the next steps in my project are based on the kickoff document and what you learned about Scrum and GitHub (if you do not, ask on Slack until you do and can check this)
